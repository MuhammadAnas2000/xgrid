package hacker;

public class implService1 implements service1{

	@Override
	public void FeedGenerator() {
		
		
		Page userinfo = //calling dao layer for accessing userinfo
				
		//userinfo2 contains the sorted list according to likes of the pages.
		page userinfo2	=	userinfo.stream(person.getClass())
		            .filter(field -> field.like == int.class && field.getName().equals("likes"))
		            .sorted(Comparator.comparingInt(field -> {
		                try {
		                    return field.getInt(userinfo);
		                }
		            }))
		
			        
			return userinfo2;
	}

}
