package hacker;

@SpringBootApplication
@RestController
public class implservice2 implements service2{

	@Override
	public void FeedPosting() {
		

	    @PostMapping("/post")
	    public Post createPost(@RequestBody PostRequest request) {
	        return post;
	    }

		
	}

}
