package hacker;

public interface service1 {
    void FeedGenerator();
}