package hacker;

public interface service2 {
    void FeedPosting();
    
    
}