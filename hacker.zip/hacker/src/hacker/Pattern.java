package hacker;

import java.util.ArrayList;

public class Pattern {
	public static void main(String[] args) {
//		System.out.println(getPattern(1, Integer.MAX_VALUE));// 123454321
		 b child = new b();
	}
}
